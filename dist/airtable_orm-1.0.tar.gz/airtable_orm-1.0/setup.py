from distutils.core import setup

setup(
    name='airtable_orm',
    version='1.0',
    description='ORM for Airtable tables',
    author='Muthupandian',
    author_email='contact@muthupandian.in',
    url='https://github.com/muthugit/airtable_python_orm',
    packages=['airtable_orm'],
)